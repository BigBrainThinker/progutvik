package utilities;

public class Constants {
    public static final String FXML_PATH_HOME = "/programutvikling/fxml";
    public static final String FXML_PATH_SLUTTBRUKER = "/programutvikling/fxml/sluttbruker";
    public static final String FXML_PATH_SUPERBRUKER = "/programutvikling/fxml/superbruker";
}
