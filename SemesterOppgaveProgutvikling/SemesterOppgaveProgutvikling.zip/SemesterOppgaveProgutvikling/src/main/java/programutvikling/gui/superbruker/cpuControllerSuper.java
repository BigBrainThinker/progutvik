package programutvikling.gui.superbruker;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class cpuControllerSuper {

    @FXML
    private TextField txtCPU;

    @FXML
    private TextField txtKlokkehastighet;

    @FXML
    private TextField txtKjerner;

    @FXML
    private TextField txtRAM;

    @FXML
    private TextField txtPris;

    @FXML
    void RegistrerCPU(ActionEvent event) {

    }

    @FXML
    void SlettCPU(ActionEvent event) {

    }

}
